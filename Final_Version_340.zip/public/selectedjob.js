function selectJob(id){
    $("#job-selector").val(id);
}